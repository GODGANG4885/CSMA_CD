
double power(double i, int j);
int power(int, int);
int min(int i, int j);
int max(int i, int j);