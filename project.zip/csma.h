#include "main.h"


void CSMA_CA(Node *node, int min_k, int max_k, int carrier_sensing);
void Print_Node_Stat(Node N);

void CSMA_CA_memory_allocation(void);
void CSMA_CA_memory_free(void);