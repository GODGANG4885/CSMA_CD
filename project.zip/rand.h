

void Bit_gen_memory_allocation(void);

void Rand_gen(void);
void Exp_Rand_gen(double *exp_rand_bit, double Lambda);
void Bit_gen(int * bit_stream, int stream_size); 

double Exp_Rand_gen1(double Lambda);
void Bit_gen_memory_free(void);